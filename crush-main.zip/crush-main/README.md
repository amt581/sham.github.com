# Confess-your-love Website 💕

It's Valentine's Day. 

As a CS major student, what's an elegant and simple way to confess your love for someone special? 

That's right, a website <3

### View it [here](https://iam-weijie.github.io/crush/confession.html)
